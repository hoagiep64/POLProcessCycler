POLProcessCycler

Requirements:
- Windows 10 or newer
- .NET Desktop Runtime 10.x (x64)

Download:
https://dotnet.microsoft.com/en-us/download/dotnet/10.0

Usage:
- Extract all files to a folder
- Run PolProcessCycler.exe as administrator
- Controller and hotkey bindings are configured in-app
