using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using Forms = System.Windows.Forms;
using System.Drawing;

namespace PolProcessCycler
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public ObservableCollection<ProcItem> Items { get; } = new();

        private HwndSource? _source;
        private bool _running;
        private int _cycleIndex = -1;
		private Forms.NotifyIcon? _trayIcon;
		private bool _isExiting = false;


        // Hotkey IDs
		private const int HOTKEY_ID_FWD = 0xB00B;
		private const int HOTKEY_ID_BACK = 0xB00C;

        public event PropertyChangedEventHandler? PropertyChanged;

        private string _selectedCountText = "Selected: 0 (need 2–8)";
        public string SelectedCountText
        {
            get => _selectedCountText;
            set { _selectedCountText = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedCountText))); }
        }
		
		private void InitializeTrayIcon()
		{
			_trayIcon = new Forms.NotifyIcon
			{
				Icon = new Icon("Assets\\pol_cycle.ico"), // <-- your custom icon
				Text = "pol.exe Cycler",
				Visible = true
			};

			_trayIcon.DoubleClick += (s, e) =>
			{
				Show();
				WindowState = WindowState.Normal;
				Activate();
			};

			var menu = new Forms.ContextMenuStrip();
			menu.Items.Add("Open", null, (s, e) =>
			{
				Show();
				WindowState = WindowState.Normal;
				Activate();
			});
			menu.Items.Add("Exit", null, (s, e) =>
			{
				_isExiting = true;
				Close();
			});

			_trayIcon.ContextMenuStrip = menu;
		}


        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            ProcessList.ItemsSource = Items;
        }
		
		protected override void OnStateChanged(EventArgs e)
		{
			base.OnStateChanged(e);

			if (WindowState == WindowState.Minimized)
			{
				Hide();
			}
		}


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshProcessList();
            HookWindowMessages();
			InitializeTrayIcon();
        }

        private void Window_Closing(object sender, CancelEventArgs e)
		{
			if (!_isExiting)
			{
				e.Cancel = true;
				Hide();
				return;
			}

			StopCycling();
			UnhookWindowMessages();

			if (_trayIcon != null)
			{
				_trayIcon.Visible = false;
				_trayIcon.Dispose();
			}
		}


        private void HookWindowMessages()
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            _source = HwndSource.FromHwnd(hwnd);
            _source.AddHook(WndProc);
        }

        private void UnhookWindowMessages()
        {
            if (_source != null)
            {
                _source.RemoveHook(WndProc);
                _source = null;
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => RefreshProcessList();

        private void SelectAll_Click(object sender, RoutedEventArgs e)
        {
            foreach (var it in Items) it.IsSelected = true;
            UpdateSelectedCount();
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            foreach (var it in Items) it.IsSelected = false;
            UpdateSelectedCount();
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            UpdateSelectedCount();
            var selected = GetSelected();
            if (selected.Count < 2 || selected.Count > 8)
            {
                System.Windows.MessageBox.Show("Please select between 2 and 8 pol.exe processes.", "Selection required",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            RegisterSelectedHotkeys();
            _running = true;
            _cycleIndex = -1;

            StartButton.IsEnabled = false;
            StopButton.IsEnabled = true;
        }
		
		private uint GetVkFromCombo(System.Windows.Controls.ComboBox combo)
		{
			if (combo.SelectedItem is not System.Windows.Controls.ComboBoxItem item || item.Tag is null)
				throw new InvalidOperationException("Hotkey selection is invalid.");

			return item.Tag.ToString() switch
			{
				"F1" => VK_F1,
				"F2" => VK_F2,
				"F3" => VK_F3,
				"OEM_3" => VK_OEM_3,
				_ => throw new InvalidOperationException("Unknown hotkey selection.")
			};
		}



        private void Stop_Click(object sender, RoutedEventArgs e) => StopCycling();

        private void StopCycling()
        {
            if (_running)
            {
                UnregisterHotKeys();
                _running = false;
            }
            StartButton.IsEnabled = true;
            StopButton.IsEnabled = false;
        }

        private void RefreshProcessList()
		{
			// Remember which row user had highlighted for moving
			int previouslySelectedIndex = ProcessList.SelectedIndex;

			// Get currently running POL processes
			var procs = Process.GetProcessesByName("pol").ToList();

			// Map PID -> Process for quick lookup
			var byPid = new Dictionary<int, Process>();
			foreach (var p in procs)
				byPid[p.Id] = p;

			// Preserve the existing order:
			// 1) Keep Items that still exist (same PID) in the SAME order
			// 2) Append any new PIDs at the bottom
			var existingOrder = Items.Select(x => x.Pid).ToList();
			var existingSelected = Items.Where(x => x.IsSelected).Select(x => x.Pid).ToHashSet();

			var newItems = new List<ProcItem>();

			// Keep old order for still-running PIDs
			foreach (var pid in existingOrder)
			{
				if (!byPid.TryGetValue(pid, out var p))
					continue;

				string title = "";
				try { title = p.MainWindowTitle ?? ""; } catch { /* ignore */ }

				newItems.Add(new ProcItem
				{
					Pid = pid,
					IsSelected = existingSelected.Contains(pid),
					DisplayName = $"PID {pid}  |  {(string.IsNullOrWhiteSpace(title) ? "(no title yet)" : title)}"
				});

				byPid.Remove(pid); // remove so we can later append only "new" ones
			}

			// Append brand new POL instances (not previously in the list), sorted by PID for stability
			foreach (var kvp in byPid.OrderBy(k => k.Key))
			{
				var p = kvp.Value;

				string title = "";
				try { title = p.MainWindowTitle ?? ""; } catch { /* ignore */ }

				newItems.Add(new ProcItem
				{
					Pid = p.Id,
					IsSelected = false,
					DisplayName = $"PID {p.Id}  |  {(string.IsNullOrWhiteSpace(title) ? "(no title yet)" : title)}"
				});
			}

			// Apply
			Items.Clear();
			foreach (var it in newItems)
				Items.Add(it);

			UpdateSelectedCount();

			// Restore highlight row if possible
			if (Items.Count > 0)
			{
				if (previouslySelectedIndex >= 0 && previouslySelectedIndex < Items.Count)
					ProcessList.SelectedIndex = previouslySelectedIndex;
				else
					ProcessList.SelectedIndex = Math.Min(Items.Count - 1, Math.Max(0, previouslySelectedIndex));
			}
		}


        private List<int> GetSelected()
        {
            return Items.Where(x => x.IsSelected).Select(x => x.Pid).ToList();
        }

        private void UpdateSelectedCount()
        {
            var c = Items.Count(x => x.IsSelected);
            SelectedCountText = $"Selected: {c} (need 2–8)";
        }

        private void RegisterSelectedHotkeys()
		{
			UnregisterHotKeys(); // in case already registered

			var hwnd = new WindowInteropHelper(this).Handle;
			uint modifiers = MOD_CONTROL | MOD_ALT;

			uint vkFwd = GetVkFromCombo(HotkeyForwardCombo);
			uint vkBack = GetVkFromCombo(HotkeyBackCombo);

			if (vkFwd == vkBack)
			{
				System.Windows.MessageBox.Show(
					"Forward and Back hotkeys must be different.",
					"Hotkey error",
					MessageBoxButton.OK,
					MessageBoxImage.Warning);
				return;
			}

			if (!RegisterHotKey(hwnd, HOTKEY_ID_FWD, modifiers, vkFwd))
			{
				System.Windows.MessageBox.Show("Failed to register Forward hotkey.",
					"Hotkey error", MessageBoxButton.OK, MessageBoxImage.Warning);
			}

			if (!RegisterHotKey(hwnd, HOTKEY_ID_BACK, modifiers, vkBack))
			{
				System.Windows.MessageBox.Show("Failed to register Back hotkey.",
					"Hotkey error", MessageBoxButton.OK, MessageBoxImage.Warning);
			}
		}



        private void UnregisterHotKeys()
		{
			var hwnd = new WindowInteropHelper(this).Handle;
			UnregisterHotKey(hwnd, HOTKEY_ID_FWD);
			UnregisterHotKey(hwnd, HOTKEY_ID_BACK);
		}
	
		private DateTime _lastHotkey = DateTime.MinValue;
		private readonly TimeSpan _hotkeyCooldown = TimeSpan.FromMilliseconds(200);

		private bool HotkeyAllowed()
		{
			if (DateTime.Now - _lastHotkey < _hotkeyCooldown)
				return false;

			_lastHotkey = DateTime.Now;
			return true;
		}

		private void CycleForward()
		{
			if (!HotkeyAllowed()) return;

			var selected = GetSelected();
			if (selected.Count < 2) return;

			_cycleIndex = (_cycleIndex + 1) % selected.Count;
			ActivatePid(selected[_cycleIndex]);
		}

		private void CycleBackward()
		{
			if (!HotkeyAllowed()) return;

			var selected = GetSelected();
			if (selected.Count < 2) return;

			// Wrap correctly for negative
			_cycleIndex = (_cycleIndex - 1 + selected.Count) % selected.Count;
			ActivatePid(selected[_cycleIndex]);
		}

		private void ActivatePid(int pid)
		{
			var hwnd = WindowFinder.FindBestTopLevelWindowForPid(pid);
			if (hwnd == IntPtr.Zero)
				return;

			WindowFinder.BringToFront(hwnd);
		}


        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
		{
			if (msg == WM_HOTKEY)
			{
				int id = wParam.ToInt32();

				if (id == HOTKEY_ID_FWD)
				{
					CycleForward();
					handled = true;
				}
				else if (id == HOTKEY_ID_BACK)
				{
					CycleBackward();
					handled = true;
				}
			}

			return IntPtr.Zero;
		}
		
		private void MoveUp_Click(object sender, RoutedEventArgs e)
		{
			int i = ProcessList.SelectedIndex;
			if (i <= 0) return;

			var item = Items[i];
			Items.RemoveAt(i);
			Items.Insert(i - 1, item);

			ProcessList.SelectedIndex = i - 1;
			ProcessList.ScrollIntoView(item);
		}

		private void MoveDown_Click(object sender, RoutedEventArgs e)
		{
			int i = ProcessList.SelectedIndex;
			if (i < 0 || i >= Items.Count - 1) return;

			var item = Items[i];
			Items.RemoveAt(i);
			Items.Insert(i + 1, item);

			ProcessList.SelectedIndex = i + 1;
			ProcessList.ScrollIntoView(item);
		}

        // Win32
        private const int WM_HOTKEY = 0x0312;
        private const uint MOD_ALT = 0x0001;
        private const uint MOD_CONTROL = 0x0002;

        private const uint VK_OEM_3 = 0xC0; // `~
        private const uint VK_F1 = 0x70;
        private const uint VK_F2 = 0x71;
        private const uint VK_F3 = 0x72;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    }

    public class ProcItem : INotifyPropertyChanged
    {
        public int Pid { get; set; }
        public string DisplayName { get; set; } = "";

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set { _isSelected = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected))); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
