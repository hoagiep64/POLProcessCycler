using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace PolProcessCycler
{
    internal static class WindowFinder
    {
        public static IntPtr FindBestTopLevelWindowForPid(int pid)
        {
            var candidates = new List<IntPtr>();

            EnumWindows((hWnd, lParam) =>
            {
                if (!IsWindowVisible(hWnd))
                    return true;

                // Skip owned windows (often tool windows / popups)
                IntPtr owner = GetWindow(hWnd, GW_OWNER);
                if (owner != IntPtr.Zero)
                    return true;

                // Skip tool windows
                var exStyle = GetWindowLongPtr(hWnd, GWL_EXSTYLE).ToInt64();
                if ((exStyle & WS_EX_TOOLWINDOW) != 0)
                    return true;

                GetWindowThreadProcessId(hWnd, out var windowPid);
                if (windowPid == pid)
                {
                    // Prefer windows with a title, but allow untitled if needed
                    candidates.Add(hWnd);
                }

                return true;
            }, IntPtr.Zero);

            if (candidates.Count == 0)
                return IntPtr.Zero;

            // Pick best:
            // 1) Has a non-empty title
            // 2) Otherwise first candidate
            foreach (var h in candidates)
            {
                if (GetWindowTextLength(h) > 0)
                    return h;
            }

            return candidates[0];
        }

        public static void BringToFront(IntPtr hWnd)
        {
            // Restore if minimized
            ShowWindow(hWnd, SW_RESTORE);

            // Try to foreground
            SetForegroundWindow(hWnd);
        }

        // Win32
        private const int GWL_EXSTYLE = -20;
        private const long WS_EX_TOOLWINDOW = 0x00000080L;
        private const uint GW_OWNER = 4;

        private const int SW_RESTORE = 9;

        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern int GetWindowTextLength(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindow(IntPtr hWnd, uint uCmd);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("user32.dll", EntryPoint = "GetWindowLongPtr")]
        private static extern IntPtr GetWindowLongPtr64(IntPtr hWnd, int nIndex);

        // Fallback for 32-bit (not typical on Win11, but safe)
        [DllImport("user32.dll", EntryPoint = "GetWindowLong")]
        private static extern IntPtr GetWindowLongPtr32(IntPtr hWnd, int nIndex);

        private static IntPtr GetWindowLongPtr(IntPtr hWnd, int nIndex)
        {
            if (IntPtr.Size == 8) return GetWindowLongPtr64(hWnd, nIndex);
            return GetWindowLongPtr32(hWnd, nIndex);
        }

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);
    }
}
