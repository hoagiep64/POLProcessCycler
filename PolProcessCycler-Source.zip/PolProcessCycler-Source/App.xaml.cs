﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace PolProcessCycler;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : System.Windows.Application
{
	private static Mutex? _mutex;

    protected override void OnStartup(StartupEventArgs e)
    {
        const string mutexName = @"Local\PolProcessCycler_SingleInstance";
        _mutex = new Mutex(true, mutexName, out bool createdNew);

        if (!createdNew)
        {
            System.Windows.MessageBox.Show(
                "POLProcessCycler is already running.\n\n" +
                "Check the system tray for the existing instance.",
                "Already running",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            Shutdown();
            return;
        }

        base.OnStartup(e);
    }

    protected override void OnExit(ExitEventArgs e)
    {
        try
        {
            _mutex?.ReleaseMutex();
        }
        catch { /* ignore */ }

        _mutex?.Dispose();
        _mutex = null;

        base.OnExit(e);
    }
}

