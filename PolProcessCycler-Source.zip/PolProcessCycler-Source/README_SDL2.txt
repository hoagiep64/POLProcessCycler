POLProcessCycler V2 (SDL2 Controller Support)

This project adds native controller input using SDL2's GameController API.

What you need to add manually
----------------------------
1) SDL2.dll
   - Download the official SDL2 runtime for Windows (x64 recommended).
   - Copy SDL2.dll to:
       PolProcessCycler/Native/x64/SDL2.dll
   - When you build/publish, it will be copied next to the app.

2) (Optional) gamecontrollerdb.txt
   - SDL's community mapping DB improves support for generic controllers.
   - Put it here:
       PolProcessCycler/Native/gamecontrollerdb.txt

How to use (in-app)
-------------------
- In the UI, under "Controller (SDL2)":
  - Enable controller input
  - Select your controller (or click Refresh)
  - Default binds are D-pad Right = Forward, D-pad Left = Back
  - Click Bind to assign any button or axis flick

Notes
-----
- Bind capture timeout: 5 seconds
- Poll rate: ~60 Hz
- Cycle actions still go through the same 200ms cooldown used by hotkeys
