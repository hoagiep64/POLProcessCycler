using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace PolProcessCycler
{
    internal static class WindowFinder
    {
        public static IntPtr FindBestTopLevelWindowForPid(int pid)
        {
            var candidates = new List<IntPtr>();

            EnumWindows((hWnd, lParam) =>
            {
                if (!IsWindowVisible(hWnd))
                    return true;

                // Skip owned windows (often tool windows / popups)
                IntPtr owner = GetWindow(hWnd, GW_OWNER);
                if (owner != IntPtr.Zero)
                    return true;

                // Skip tool windows
                var exStyle = GetWindowLongPtr(hWnd, GWL_EXSTYLE).ToInt64();
                if ((exStyle & WS_EX_TOOLWINDOW) != 0)
                    return true;

                GetWindowThreadProcessId(hWnd, out var windowPid);
                if (windowPid == pid)
                {
                    // Prefer windows with a title, but allow untitled if needed
                    candidates.Add(hWnd);
                }

                return true;
            }, IntPtr.Zero);

            if (candidates.Count == 0)
                return IntPtr.Zero;

            // Pick best:
            // 1) Has a non-empty title
            // 2) Otherwise first candidate
            foreach (var h in candidates)
            {
                if (GetWindowTextLength(h) > 0)
                    return h;
            }

            return candidates[0];
        }

        public static void BringToFront(IntPtr hWnd)
		{
			if (hWnd == IntPtr.Zero)
				return;

			// Restore if minimized
			ShowWindow(hWnd, SW_RESTORE);

			// 1) First attempt (simple)
			BringWindowToTop(hWnd);
			SetForegroundWindow(hWnd);
			if (GetForegroundWindow() == hWnd)
				return;

			// 2) AttachThreadInput attempt
			IntPtr fg = GetForegroundWindow();
			uint fgThread = fg != IntPtr.Zero ? GetWindowThreadProcessId(fg, out _) : 0;
			uint targetThread = GetWindowThreadProcessId(hWnd, out _);
			uint thisThread = GetCurrentThreadId();

			bool attachedFg = false;
			bool attachedTarget = false;

			try
			{
				if (fgThread != 0 && fgThread != thisThread)
					attachedFg = AttachThreadInput(fgThread, thisThread, true);

				if (targetThread != 0 && targetThread != thisThread)
					attachedTarget = AttachThreadInput(targetThread, thisThread, true);

				BringWindowToTop(hWnd);
				SetForegroundWindow(hWnd);

				if (GetForegroundWindow() == hWnd)
					return;

			}
			finally
			{
				if (attachedTarget)
					AttachThreadInput(targetThread, thisThread, false);

				if (attachedFg)
					AttachThreadInput(fgThread, thisThread, false);
			}

			// 3) ALT key trick (makes Windows treat it like real user input), then retry
			TapAltKey();
			BringWindowToTop(hWnd);
			SetForegroundWindow(hWnd);
			if (GetForegroundWindow() == hWnd)
				return;

			// 4) Last resort: topmost toggle + retry
			SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
			SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);

			BringWindowToTop(hWnd);
			SetForegroundWindow(hWnd);
		}

        // Win32
        private const int GWL_EXSTYLE = -20;
        private const long WS_EX_TOOLWINDOW = 0x00000080L;
        private const uint GW_OWNER = 4;

        private const int SW_RESTORE = 9;

        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern int GetWindowTextLength(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindow(IntPtr hWnd, uint uCmd);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("user32.dll", EntryPoint = "GetWindowLongPtr")]
        private static extern IntPtr GetWindowLongPtr64(IntPtr hWnd, int nIndex);

        // Fallback for 32-bit (not typical on Win11, but safe)
        [DllImport("user32.dll", EntryPoint = "GetWindowLong")]
        private static extern IntPtr GetWindowLongPtr32(IntPtr hWnd, int nIndex);

        private static IntPtr GetWindowLongPtr(IntPtr hWnd, int nIndex)
        {
            if (IntPtr.Size == 8) return GetWindowLongPtr64(hWnd, nIndex);
            return GetWindowLongPtr32(hWnd, nIndex);
        }

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);
		
		[DllImport("user32.dll")]
		private static extern IntPtr GetForegroundWindow();

		[DllImport("kernel32.dll")]
		private static extern uint GetCurrentThreadId();

		[DllImport("user32.dll")]
		private static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

		[DllImport("user32.dll")]
		private static extern bool BringWindowToTop(IntPtr hWnd);

		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter,
			int X, int Y, int cx, int cy, uint uFlags);

		[DllImport("user32.dll", SetLastError = true)]
		private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

		private static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
		private static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);

		private const uint SWP_NOSIZE = 0x0001;
		private const uint SWP_NOMOVE = 0x0002;
		private const uint SWP_NOACTIVATE = 0x0010;
		private const uint SWP_SHOWWINDOW = 0x0040;

		private const uint INPUT_KEYBOARD = 1;
		private const uint KEYEVENTF_KEYUP = 0x0002;
		private const ushort VK_MENU = 0x12; // ALT

		[StructLayout(LayoutKind.Sequential)]
		private struct INPUT
		{
			public uint type;
			public InputUnion U;
		}

		[StructLayout(LayoutKind.Explicit)]
		private struct InputUnion
		{
			[FieldOffset(0)] public KEYBDINPUT ki;
		}

		[StructLayout(LayoutKind.Sequential)]
		private struct KEYBDINPUT
		{
			public ushort wVk;
			public ushort wScan;
			public uint dwFlags;
			public uint time;
			public IntPtr dwExtraInfo;
		}

		private static void TapAltKey()
		{
			var inputs = new INPUT[2];

			inputs[0] = new INPUT
			{
				type = INPUT_KEYBOARD,
				U = new InputUnion { ki = new KEYBDINPUT { wVk = VK_MENU, dwFlags = 0 } }
			};

			inputs[1] = new INPUT
			{
				type = INPUT_KEYBOARD,
				U = new InputUnion { ki = new KEYBDINPUT { wVk = VK_MENU, dwFlags = KEYEVENTF_KEYUP } }
			};

			SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<INPUT>());
		}

    }
}
