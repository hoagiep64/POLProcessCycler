using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Threading;
using Forms = System.Windows.Forms;
using System.Drawing;
using PolProcessCycler.Input;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace PolProcessCycler
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public ObservableCollection<ProcItem> Items { get; } = new();

        private HwndSource? _source;
        private bool _running;
        private int _cycleIndex = -1;
		private Forms.NotifyIcon? _trayIcon;
		private bool _isExiting = false;

		// SDL2 controller support
		private SdlControllerService? _controllerService;
		private DispatcherTimer? _controllerTimer;
		private readonly ControllerBindings _controllerBindings = new();
		private bool _prevControllerFwd;
		private bool _prevControllerBack;
		private static readonly string SettingsDir =
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "PolProcessCycler");
		private static readonly string SettingsPath =
			Path.Combine(SettingsDir, "controller_bindings.json");

		private enum CaptureMode { None, Forward, Back }
		private CaptureMode _captureMode = CaptureMode.None;
		private DateTime _captureUntil = DateTime.MinValue;
		private bool[] _capturePrevButtons = Array.Empty<bool>();
		private short[] _capturePrevAxes = Array.Empty<short>();
        // Hotkey IDs
		private const int HOTKEY_ID_FWD = 0xB00B;
		private const int HOTKEY_ID_BACK = 0xB00C;

        public event PropertyChangedEventHandler? PropertyChanged;

        private string _selectedCountText = "Selected: 0 (need 2–8)";
        public string SelectedCountText
        {
            get => _selectedCountText;
            set { _selectedCountText = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedCountText))); }
        }
		
		private static bool IsCurrentProcessElevated()
		{
			using var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
			var principal = new System.Security.Principal.WindowsPrincipal(identity);
			return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
		}
		
		private static bool IsProcessElevated(Process process)
		{
			try
			{
				using var token = OpenProcessTokenSafe(process.Handle);
				return token.IsElevated;
			}
			catch
			{
				return false;
			}
		}
		
		private sealed class SafeTokenHandle : IDisposable
	{
		public IntPtr Handle { get; }
		public bool IsElevated { get; }

		public SafeTokenHandle(IntPtr handle, bool elevated)
		{
			Handle = handle;
			IsElevated = elevated;
		}

		public void Dispose()
		{
			if (Handle != IntPtr.Zero)
				CloseHandle(Handle);
		}
	}

	private static SafeTokenHandle OpenProcessTokenSafe(IntPtr processHandle)
	{
		if (!OpenProcessToken(processHandle, TOKEN_QUERY, out var token))
			throw new Win32Exception();

		try
		{
			var elevation = new TOKEN_ELEVATION();
			int size = Marshal.SizeOf<TOKEN_ELEVATION>();

			if (!GetTokenInformation(token, TOKEN_INFORMATION_CLASS.TokenElevation,
					ref elevation, size, out _))
				throw new Win32Exception();

			return new SafeTokenHandle(token, elevation.TokenIsElevated != 0);
		}
		catch
		{
			CloseHandle(token);
			throw;
		}
	}

		private void InitializeTrayIcon()
		{
			_trayIcon = new Forms.NotifyIcon
			{
				Icon = new Icon("Assets\\pol_cycle.ico"), // <-- your custom icon
				Text = "pol.exe Cycler",
				Visible = true
			};

			_trayIcon.DoubleClick += (s, e) =>
			{
				Show();
				WindowState = WindowState.Normal;
				Activate();
			};

			var menu = new Forms.ContextMenuStrip();
			menu.Items.Add("Open", null, (s, e) =>
			{
				Show();
				WindowState = WindowState.Normal;
				Activate();
			});
			menu.Items.Add("Exit", null, (s, e) =>
			{
				_isExiting = true;
				Close();
			});

			_trayIcon.ContextMenuStrip = menu;
		}


        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            ProcessList.ItemsSource = Items;
        }
		
		protected override void OnStateChanged(EventArgs e)
		{
			base.OnStateChanged(e);

			if (WindowState == WindowState.Minimized)
			{
				Hide();
			}
		}


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshProcessList();
			foreach (var it in Items)
				it.IsSelected = true;
			UpdateSelectedCount();	
            HookWindowMessages();
			InitializeTrayIcon();
			LoadControllerBindings();
            InitializeControllerSupport();
        }

        private void Window_Closing(object sender, CancelEventArgs e)
		{
			if (!_isExiting)
			{
				e.Cancel = true;
				Hide();
				return;
			}
			StopCycling();
			UnhookWindowMessages();

            if (_controllerTimer != null)
            {
                _controllerTimer.Stop();
                _controllerTimer.Tick -= ControllerTimer_Tick;
                _controllerTimer = null;
            }

            if (_controllerService != null)
            {
				SaveControllerBindings();
                try { _controllerService.Dispose(); } catch { /* ignore */ }
                _controllerService = null;
            }

			if (_trayIcon != null)
			{
				_trayIcon.Visible = false;
				_trayIcon.Dispose();
			}
		}

        private void HookWindowMessages()
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            _source = HwndSource.FromHwnd(hwnd);
            _source.AddHook(WndProc);
        }

        private void UnhookWindowMessages()
        {
            if (_source != null)
            {
                _source.RemoveHook(WndProc);
                _source = null;
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => RefreshProcessList();

        private void SelectAll_Click(object sender, RoutedEventArgs e)
        {
            foreach (var it in Items) it.IsSelected = true;
            UpdateSelectedCount();
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            foreach (var it in Items) it.IsSelected = false;
            UpdateSelectedCount();
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            UpdateSelectedCount();
            var selected = GetSelected();
            if (selected.Count < 2 || selected.Count > 8)
            {
                System.Windows.MessageBox.Show("Please select between 2 and 8 pol.exe processes.", "Selection required",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
			
			bool cyclerElevated = IsCurrentProcessElevated();

			bool anyPolElevated = false;
			foreach (int pid in selected)
			{
				try
				{
					using var p = Process.GetProcessById(pid);
					if (IsProcessElevated(p))
					{
						anyPolElevated = true;
						break;
					}
				}
				catch { /* ignore */ }
			}

			if (cyclerElevated != anyPolElevated)
			{
				System.Windows.MessageBox.Show(
				"⚠ Elevation mismatch detected\n\n" +
				"Some selected pol.exe instances are running as Administrator while " +
				"POLProcessCycler is not (or vice versa).\n\n" +
				"Windows may block reliable window switching in this case, causing " +
				"taskbar flashing instead of proper focus.\n\n" +
				"For best results, run POLProcessCycler and pol.exe at the same " +
				"privilege level.",
				"Focus Warning",
				MessageBoxButton.OK,
				MessageBoxImage.Warning);
			}

			if (EnableHotkeysCheckBox.IsChecked == true)
			{
				if (!RegisterSelectedHotkeys())
					return;
			}
			else
			{
				UnregisterHotKeys(); // safety: ensure none are held
			}

            _running = true;
            _cycleIndex = -1;

            StartButton.IsEnabled = false;
            StopButton.IsEnabled = true;
        }
		
		private uint GetVkFromCombo(System.Windows.Controls.ComboBox combo)
		{
			if (combo.SelectedItem is not System.Windows.Controls.ComboBoxItem item || item.Tag is null)
				throw new InvalidOperationException("Hotkey selection is invalid.");

			return item.Tag.ToString() switch
			{
				"F1" => VK_F1,
				"F2" => VK_F2,
				"F3" => VK_F3,
				"OEM_3" => VK_OEM_3,
				_ => throw new InvalidOperationException("Unknown hotkey selection.")
			};
		}



        private void Stop_Click(object sender, RoutedEventArgs e) => StopCycling();

        private void StopCycling()
        {
            if (_running)
            {
                UnregisterHotKeys();
                _running = false;
            }

			// reset controller edge state so the next press after Start is clean
			_prevControllerFwd = false;
			_prevControllerBack = false;

            StartButton.IsEnabled = true;
            StopButton.IsEnabled = false;
        }

        private void RefreshProcessList()
		{
			// Remember which row user had highlighted for moving
			int previouslySelectedIndex = ProcessList.SelectedIndex;

			// Get currently running POL processes
			var procs = Process.GetProcessesByName("pol").ToList();

			// Map PID -> Process for quick lookup
			var byPid = new Dictionary<int, Process>();
			foreach (var p in procs)
				byPid[p.Id] = p;

			// Preserve the existing order:
			// 1) Keep Items that still exist (same PID) in the SAME order
			// 2) Append any new PIDs at the bottom
			var existingOrder = Items.Select(x => x.Pid).ToList();
			var existingSelected = Items.Where(x => x.IsSelected).Select(x => x.Pid).ToHashSet();

			var newItems = new List<ProcItem>();

			// Keep old order for still-running PIDs
			foreach (var pid in existingOrder)
			{
				if (!byPid.TryGetValue(pid, out var p))
					continue;

				string title = "";
				try { title = p.MainWindowTitle ?? ""; } catch { /* ignore */ }

				newItems.Add(new ProcItem
				{
					Pid = pid,
					IsSelected = existingSelected.Contains(pid),
					DisplayName = $"PID {pid}  |  {(string.IsNullOrWhiteSpace(title) ? "(no title yet)" : title)}"
				});

				byPid.Remove(pid); // remove so we can later append only "new" ones
			}

			// Append brand new POL instances (not previously in the list), sorted by PID for stability
			foreach (var kvp in byPid.OrderBy(k => k.Key))
			{
				var p = kvp.Value;

				string title = "";
				try { title = p.MainWindowTitle ?? ""; } catch { /* ignore */ }

				newItems.Add(new ProcItem
				{
					Pid = p.Id,
					IsSelected = false,
					DisplayName = $"PID {p.Id}  |  {(string.IsNullOrWhiteSpace(title) ? "(no title yet)" : title)}"
				});
			}

			// Apply
			Items.Clear();
			foreach (var it in newItems)
				Items.Add(it);

			UpdateSelectedCount();

			// Restore highlight row if possible
			if (Items.Count > 0)
			{
				if (previouslySelectedIndex >= 0 && previouslySelectedIndex < Items.Count)
					ProcessList.SelectedIndex = previouslySelectedIndex;
				else
					ProcessList.SelectedIndex = Math.Min(Items.Count - 1, Math.Max(0, previouslySelectedIndex));
			}
		}


        private List<int> GetSelected()
        {
            return Items.Where(x => x.IsSelected).Select(x => x.Pid).ToList();
        }

        private void UpdateSelectedCount()
        {
            var c = Items.Count(x => x.IsSelected);
            SelectedCountText = $"Selected: {c}";
        }

		private bool RegisterSelectedHotkeys()
		{
			UnregisterHotKeys(); // in case already registered

			var hwnd = new WindowInteropHelper(this).Handle;
			uint modifiers = MOD_CONTROL | MOD_ALT;

			uint vkFwd = GetVkFromCombo(HotkeyForwardCombo);
			uint vkBack = GetVkFromCombo(HotkeyBackCombo);

			if (vkFwd == vkBack)
			{
				System.Windows.MessageBox.Show(
					"Forward and Back hotkeys must be different.",
					"Hotkey error",
					MessageBoxButton.OK,
					MessageBoxImage.Warning);
				return false;
			}

			if (!RegisterHotKey(hwnd, HOTKEY_ID_FWD, modifiers, vkFwd))
			{
				System.Windows.MessageBox.Show("Failed to register Forward hotkey.",
					"Hotkey error", MessageBoxButton.OK, MessageBoxImage.Warning);
				return false;
			}

			if (!RegisterHotKey(hwnd, HOTKEY_ID_BACK, modifiers, vkBack))
			{
				System.Windows.MessageBox.Show("Failed to register Back hotkey.",
					"Hotkey error", MessageBoxButton.OK, MessageBoxImage.Warning);
				return false;
			}

			return true;
		}
		
		private void EnableHotkeysCheckBox_Changed(object sender, RoutedEventArgs e)
		{
			// If hotkeys are being turned off, immediately unregister them.
			if (EnableHotkeysCheckBox.IsChecked != true)
			{
				UnregisterHotKeys();
			}
		}

		private void ExitButton_Click(object sender, RoutedEventArgs e)
		{
			StopCycling();        // optional but good
			_isExiting = true;    // THIS is the key line
			Close();              // triggers Window_Closing
		}

        // -------------------------------
        // Controller (SDL2) support
        // -------------------------------

        private void InitializeControllerSupport()
        {
            try
            {
                _controllerService = new SdlControllerService();

                string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                string map1 = System.IO.Path.Combine(baseDir, "Native", "gamecontrollerdb.txt");
                string map2 = System.IO.Path.Combine(baseDir, "gamecontrollerdb.txt");
                string? mapPath = System.IO.File.Exists(map1) ? map1 : (System.IO.File.Exists(map2) ? map2 : null);

                _controllerService.Initialize(mapPath);
                PopulateControllerCombo();

                _controllerTimer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromMilliseconds(16) // ~60 Hz
                };
                _controllerTimer.Tick += ControllerTimer_Tick;
                _controllerTimer.Start();

                UpdateControllerBindingText();
            }
            catch (DllNotFoundException)
            {
                // SDL2.dll not present; leave controller UI inert.
                ControllerCombo.ItemsSource = null;
                ControllerCombo.Items.Clear();
                ControllerCombo.Items.Add("SDL2.dll not found (controller disabled)");
                ControllerCombo.SelectedIndex = 0;
                ControllerEnableCheck.IsChecked = false;
            }
            catch (Exception ex)
            {
                ControllerCombo.ItemsSource = null;
                ControllerCombo.Items.Clear();
                ControllerCombo.Items.Add($"Controller init error: {ex.Message}");
                ControllerCombo.SelectedIndex = 0;
                ControllerEnableCheck.IsChecked = false;
            }
        }

        private void PopulateControllerCombo()
        {
            if (_controllerService == null) return;

            // IMPORTANT: You cannot set ItemsSource if the ComboBox already has Items.
            // Always clear the Items collection first to avoid:
            // "Items collection must be empty before using ItemsSource."
            ControllerCombo.ItemsSource = null;
            ControllerCombo.Items.Clear();

            _controllerService.RefreshControllers();

            if (_controllerService.Available.Count == 0)
            {
                ControllerCombo.Items.Add("(no controller detected)");
                ControllerCombo.SelectedIndex = 0;
                return;
            }

            ControllerCombo.ItemsSource = _controllerService.Available;
            ControllerCombo.SelectedIndex = 0;

            // Open the selected controller
            _controllerService.OpenController(((ControllerInfo)ControllerCombo.SelectedItem).Index);
        }

        private void ControllerRefresh_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                PopulateControllerCombo();
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Controller", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ControllerCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_controllerService == null) return;
            if (ControllerCombo.SelectedItem is not ControllerInfo)
                return;

            try
            {
                _controllerService.OpenController(((ControllerInfo)ControllerCombo.SelectedItem).Index);
                _prevControllerFwd = false;
                _prevControllerBack = false;
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Controller", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BindForward_Click(object sender, RoutedEventArgs e) => StartCapture(CaptureMode.Forward);
        private void BindBack_Click(object sender, RoutedEventArgs e) => StartCapture(CaptureMode.Back);

        private void StartCapture(CaptureMode mode)
        {
            if (_controllerService == null || !_controllerService.HasOpenController)
            {
                System.Windows.MessageBox.Show("No controller is open. Plug one in and click Refresh.", "Controller",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            _captureMode = mode;
            _captureUntil = DateTime.Now.AddSeconds(5);

            // Seed prev state so "currently held" doesn't count as a new bind.
            _capturePrevButtons = ReadAllButtons();
            _capturePrevAxes = ReadAllAxes();

            if (mode == CaptureMode.Forward)
                ControllerForwardText.Text = "Press a button / move an axis...";
            else
                ControllerBackText.Text = "Press a button / move an axis...";
        }

        private void ControllerTimer_Tick(object? sender, EventArgs e)
        {
            if (_controllerService == null || !_controllerService.IsReady)
                return;

            // Keep SDL event pump alive
            _controllerService.Pump();

            // Handle bind capture (works even if not "Started")
            if (_captureMode != CaptureMode.None)
            {
                if (DateTime.Now > _captureUntil)
                {
                    _captureMode = CaptureMode.None;
                    UpdateControllerBindingText();
                    return;
                }

                if (TryCaptureNewBinding(out var captured))
                {
                    if (_captureMode == CaptureMode.Forward)
                        _controllerBindings.Forward = captured;
                    else if (_captureMode == CaptureMode.Back)
                        _controllerBindings.Back = captured;

                    _captureMode = CaptureMode.None;
                    UpdateControllerBindingText();
					SaveControllerBindings();
                }

                return; // don't cycle while binding
            }

            // Normal cycling
            if (!_running) return;
            if (ControllerEnableCheck.IsChecked != true) return;
            if (!_controllerService.HasOpenController) return;

            bool fwd = IsBindingActive(_controllerBindings.Forward);
            bool back = IsBindingActive(_controllerBindings.Back);

            if (fwd && !_prevControllerFwd)
                CycleForward();
            else if (back && !_prevControllerBack)
                CycleBackward();

            _prevControllerFwd = fwd;
            _prevControllerBack = back;
        }

        private bool IsBindingActive(InputBinding bind)
        {
            if (_controllerService == null) return false;

            return bind.Kind switch
            {
                InputKind.Button => _controllerService.GetButton(bind.Button),
                InputKind.AxisPositive => NormalizeAxis(_controllerService.GetAxis(bind.Axis)) >= bind.Threshold,
                InputKind.AxisNegative => NormalizeAxis(_controllerService.GetAxis(bind.Axis)) <= -bind.Threshold,
                _ => false
            };
        }

        private static float NormalizeAxis(short v)
        {
            // SDL axis is [-32768..32767]
            if (v >= 0) return v / 32767f;
            return v / 32768f;
        }

        private void UpdateControllerBindingText()
        {
            ControllerForwardText.Text = _controllerBindings.Forward.Display;
            ControllerBackText.Text = _controllerBindings.Back.Display;
        }

        private bool[] ReadAllButtons()
        {
            if (_controllerService == null) return Array.Empty<bool>();
            int max = (int)Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_MAX;
            var arr = new bool[max];
            for (int i = 0; i < max; i++)
            {
                var b = (Sdl2Native.SDL_GameControllerButton)i;
                arr[i] = _controllerService.GetButton(b);
            }
            return arr;
        }

        private short[] ReadAllAxes()
        {
            if (_controllerService == null) return Array.Empty<short>();
            int max = (int)Sdl2Native.SDL_GameControllerAxis.SDL_CONTROLLER_AXIS_MAX;
            var arr = new short[max];
            for (int i = 0; i < max; i++)
            {
                var a = (Sdl2Native.SDL_GameControllerAxis)i;
                arr[i] = _controllerService.GetAxis(a);
            }
            return arr;
        }

        private bool TryCaptureNewBinding(out InputBinding binding)
        {
            binding = new InputBinding();
            if (_controllerService == null || !_controllerService.HasOpenController)
                return false;

            // Buttons: find a rising edge
            var curButtons = ReadAllButtons();
            if (_capturePrevButtons.Length == 0)
                _capturePrevButtons = new bool[curButtons.Length];

            for (int i = 0; i < curButtons.Length; i++)
            {
                if (curButtons[i] && !_capturePrevButtons[i])
                {
                    binding = new InputBinding
                    {
                        Kind = InputKind.Button,
                        Button = (Sdl2Native.SDL_GameControllerButton)i
                    };
                    _capturePrevButtons = curButtons;
                    _capturePrevAxes = ReadAllAxes();
                    return true;
                }
            }

            _capturePrevButtons = curButtons;

            // Axes: detect a "flick" past a threshold with edge semantics.
            var curAxes = ReadAllAxes();
            if (_capturePrevAxes.Length == 0)
                _capturePrevAxes = new short[curAxes.Length];

            const float threshold = 0.75f;
            for (int i = 0; i < curAxes.Length; i++)
            {
                float cur = NormalizeAxis(curAxes[i]);
                float prev = NormalizeAxis(_capturePrevAxes[i]);

                if (cur >= threshold && prev < threshold)
                {
                    binding = new InputBinding
                    {
                        Kind = InputKind.AxisPositive,
                        Axis = (Sdl2Native.SDL_GameControllerAxis)i,
                        Threshold = threshold
                    };
                    _capturePrevAxes = curAxes;
                    return true;
                }
                if (cur <= -threshold && prev > -threshold)
                {
                    binding = new InputBinding
                    {
                        Kind = InputKind.AxisNegative,
                        Axis = (Sdl2Native.SDL_GameControllerAxis)i,
                        Threshold = threshold
                    };
                    _capturePrevAxes = curAxes;
                    return true;
                }
            }

            _capturePrevAxes = curAxes;
            return false;
        }



        private void UnregisterHotKeys()
		{
			var hwnd = new WindowInteropHelper(this).Handle;
			UnregisterHotKey(hwnd, HOTKEY_ID_FWD);
			UnregisterHotKey(hwnd, HOTKEY_ID_BACK);
		}
	
		private DateTime _lastHotkey = DateTime.MinValue;
		private readonly TimeSpan _hotkeyCooldown = TimeSpan.FromMilliseconds(100);

		private bool HotkeyAllowed()
		{
			if (DateTime.Now - _lastHotkey < _hotkeyCooldown)
				return false;

			_lastHotkey = DateTime.Now;
			return true;
		}

		private void CycleForward()
		{
			if (!HotkeyAllowed()) return;

			var selected = GetSelected();
			if (selected.Count < 2) return;

			_cycleIndex = (_cycleIndex + 1) % selected.Count;
			ActivatePid(selected[_cycleIndex]);
		}

		private void CycleBackward()
		{
			if (!HotkeyAllowed()) return;

			var selected = GetSelected();
			if (selected.Count < 2) return;

			// Wrap correctly for negative
			_cycleIndex = (_cycleIndex - 1 + selected.Count) % selected.Count;
			ActivatePid(selected[_cycleIndex]);
		}

		private void ActivatePid(int pid)
		{
			var hwnd = WindowFinder.FindBestTopLevelWindowForPid(pid);
			if (hwnd == IntPtr.Zero)
				return;

			WindowFinder.BringToFront(hwnd);
		}


        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
		{
			if (msg == WM_HOTKEY)
			{
				int id = wParam.ToInt32();

				if (id == HOTKEY_ID_FWD)
				{
					CycleForward();
					handled = true;
				}
				else if (id == HOTKEY_ID_BACK)
				{
					CycleBackward();
					handled = true;
				}
			}

			return IntPtr.Zero;
		}
		
		private void MoveUp_Click(object sender, RoutedEventArgs e)
		{
			int i = ProcessList.SelectedIndex;
			if (i <= 0) return;

			var item = Items[i];
			Items.RemoveAt(i);
			Items.Insert(i - 1, item);

			ProcessList.SelectedIndex = i - 1;
			ProcessList.ScrollIntoView(item);
		}

		private void MoveDown_Click(object sender, RoutedEventArgs e)
		{
			int i = ProcessList.SelectedIndex;
			if (i < 0 || i >= Items.Count - 1) return;

			var item = Items[i];
			Items.RemoveAt(i);
			Items.Insert(i + 1, item);

			ProcessList.SelectedIndex = i + 1;
			ProcessList.ScrollIntoView(item);
		}

        // Win32
        private const int WM_HOTKEY = 0x0312;
        private const uint MOD_ALT = 0x0001;
        private const uint MOD_CONTROL = 0x0002;

        private const uint VK_OEM_3 = 0xC0; // `~
        private const uint VK_F1 = 0x70;
        private const uint VK_F2 = 0x71;
        private const uint VK_F3 = 0x72;
		
		private const int TOKEN_QUERY = 0x0008;
		
		[DllImport("advapi32.dll", SetLastError = true)]
		private static extern bool OpenProcessToken(
			IntPtr ProcessHandle,
			int DesiredAccess,
			out IntPtr TokenHandle);

		[DllImport("advapi32.dll", SetLastError = true)]
		private static extern bool GetTokenInformation(
			IntPtr TokenHandle,
			TOKEN_INFORMATION_CLASS TokenInformationClass,
			ref TOKEN_ELEVATION TokenInformation,
			int TokenInformationLength,
			out int ReturnLength);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool CloseHandle(IntPtr hObject);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);
		
		private enum TOKEN_INFORMATION_CLASS
		{
			TokenElevation = 20
		}

		private struct TOKEN_ELEVATION
		{
			public int TokenIsElevated;
		}
		
		private sealed class ControllerBindingsFile
		{
			public BindingDto Forward { get; set; } = new();
			public BindingDto Back { get; set; } = new();
		}

		private sealed class BindingDto
		{
			public int Kind { get; set; }
			public int Button { get; set; }
			public int Axis { get; set; }
			public float Threshold { get; set; }
		}

		private void SaveControllerBindings()
		{
			try
			{
				Directory.CreateDirectory(SettingsDir);

				var file = new ControllerBindingsFile
				{
					Forward = ToDto(_controllerBindings.Forward),
					Back = ToDto(_controllerBindings.Back),
				};

				var json = JsonSerializer.Serialize(file, new JsonSerializerOptions
				{
					WriteIndented = true
				});

				File.WriteAllText(SettingsPath, json);
			}
			catch
			{
				// ignore (optional: log)
			}
		}

		private void LoadControllerBindings()
		{
			try
			{
				if (!File.Exists(SettingsPath))
					return;

				var json = File.ReadAllText(SettingsPath);
				var file = JsonSerializer.Deserialize<ControllerBindingsFile>(json);

				if (file == null) return;

				_controllerBindings.Forward = FromDto(file.Forward);
				_controllerBindings.Back = FromDto(file.Back);
			}
			catch
			{
				// ignore (optional: log)
			}
		}

		private static BindingDto ToDto(InputBinding b) => new()
		{
			Kind = (int)b.Kind,
			Button = (int)b.Button,
			Axis = (int)b.Axis,
			Threshold = b.Threshold
		};

		private static InputBinding FromDto(BindingDto d) => new()
		{
			Kind = (InputKind)d.Kind,
			Button = (Sdl2Native.SDL_GameControllerButton)d.Button,
			Axis = (Sdl2Native.SDL_GameControllerAxis)d.Axis,
			Threshold = d.Threshold
		};
    }

    public class ProcItem : INotifyPropertyChanged
    {
        public int Pid { get; set; }
        public string DisplayName { get; set; } = "";

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set { _isSelected = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected))); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
