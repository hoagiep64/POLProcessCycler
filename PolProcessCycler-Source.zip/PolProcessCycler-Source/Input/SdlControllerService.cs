using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace PolProcessCycler.Input
{
    internal sealed class ControllerInfo
	{
		public int Index { get; init; }
		public string Name { get; init; } = "Unknown";
		public bool IsGameController { get; init; }

		public override string ToString()
			=> $"{Index}: {Name} {(IsGameController ? "(GameController)" : "(Joystick)")}";
	}

    /// <summary>
    /// Simple SDL2 GameController manager (enumerate, open one controller, poll).
    /// </summary>
    internal sealed class SdlControllerService : IDisposable
    {
        private bool _initialized;
        private IntPtr _controller = IntPtr.Zero;

        public List<ControllerInfo> Available { get; private set; } = new();
        public int SelectedIndex { get; private set; } = -1;

        public bool IsReady => _initialized;
        public bool HasOpenController => _controller != IntPtr.Zero;

        public void Initialize(string? mappingsFilePath = null)
		{
			if (_initialized) return;

			// Hints: improve HID controller support (DualSense / DualShock / Switch Pro / 8BitDo)
			// Must be set BEFORE SDL_Init.
			Sdl2Native.SDL_SetHint("SDL_JOYSTICK_HIDAPI", "1");
			Sdl2Native.SDL_SetHint("SDL_JOYSTICK_HIDAPI_PS5", "1");
			Sdl2Native.SDL_SetHint("SDL_JOYSTICK_HIDAPI_PS4", "1");
			Sdl2Native.SDL_SetHint("SDL_JOYSTICK_HIDAPI_SWITCH", "1");
			Sdl2Native.SDL_SetHint("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", "1");

			uint flags = Sdl2Native.SDL_INIT_GAMECONTROLLER | Sdl2Native.SDL_INIT_EVENTS;

			int rc = Sdl2Native.SDL_Init(flags);
			if (rc < 0) // SDL_Init returns 0 on success, negative on failure
				throw new InvalidOperationException($"SDL_Init failed: {Sdl2Native.GetErrorString()}");

			// Optional mapping DB to improve support for generic/8BitDo/etc.
			if (!string.IsNullOrWhiteSpace(mappingsFilePath) && File.Exists(mappingsFilePath))
			{
				try
				{
					// Newer SDL2 builds
					_ = Sdl2Native.SDL_GameControllerAddMappingsFromFile(mappingsFilePath);
				}
				catch (EntryPointNotFoundException)
				{
					// Older/minimal SDL2 builds fallback
					var rw = Sdl2Native.SDL_RWFromFile(mappingsFilePath, "rb");
					if (rw == IntPtr.Zero)
						throw new InvalidOperationException(
							"SDL_RWFromFile failed: " + Sdl2Native.GetErrorString());

					int added = Sdl2Native.SDL_GameControllerAddMappingsFromRW(rw, 1);
					if (added < 0)
						throw new InvalidOperationException(
							"SDL_GameControllerAddMappingsFromRW failed: " + Sdl2Native.GetErrorString());
				}
			}

			_initialized = true;
			RefreshControllers();
		}


        public void RefreshControllers()
		{
			if (!_initialized) return;

			var list = new List<ControllerInfo>();
			int n = Sdl2Native.SDL_NumJoysticks();

			for (int i = 0; i < n; i++)
			{
				bool isGc = Sdl2Native.SDL_IsGameController(i);

				string name = "Controller";
				IntPtr namePtr = Sdl2Native.SDL_JoystickNameForIndex(i);
				if (namePtr != IntPtr.Zero)
					name = System.Runtime.InteropServices.Marshal.PtrToStringAnsi(namePtr) ?? name;

				list.Add(new ControllerInfo
				{
					Index = i,
					Name = name,
					IsGameController = isGc
				});
			}

			Available = list;
		}

        public void OpenController(int selectedListIndex)
        {
            if (!_initialized) return;
            CloseController();

            if (selectedListIndex < 0 || selectedListIndex >= Available.Count)
            {
                SelectedIndex = -1;
                return;
            }

            SelectedIndex = selectedListIndex;
            int sdlIndex = Available[selectedListIndex].Index;
            _controller = Sdl2Native.SDL_GameControllerOpen(sdlIndex);
            if (_controller == IntPtr.Zero)
            {
                SelectedIndex = -1;
                throw new InvalidOperationException($"Failed to open controller: {Sdl2Native.GetErrorString()}");
            }
        }

        public void CloseController()
        {
            if (_controller != IntPtr.Zero)
            {
                Sdl2Native.SDL_GameControllerClose(_controller);
                _controller = IntPtr.Zero;
            }
        }

        public void Pump()
        {
            if (!_initialized) return;
            Sdl2Native.SDL_PumpEvents();
        }

        public bool GetButton(Sdl2Native.SDL_GameControllerButton button)
        {
            if (_controller == IntPtr.Zero) return false;
            return Sdl2Native.SDL_GameControllerGetButton(_controller, button) != 0;
        }

        public short GetAxis(Sdl2Native.SDL_GameControllerAxis axis)
        {
            if (_controller == IntPtr.Zero) return 0;
            return Sdl2Native.SDL_GameControllerGetAxis(_controller, axis);
        }

        public void Dispose()
        {
            try { CloseController(); } catch { /* ignore */ }
            if (_initialized)
            {
                try { Sdl2Native.SDL_Quit(); } catch { /* ignore */ }
                _initialized = false;
            }
        }
    }
}
