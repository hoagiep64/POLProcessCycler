using System;
using System.Runtime.InteropServices;

namespace PolProcessCycler.Input
{
    /// <summary>
    /// Minimal SDL2 P/Invoke surface for the GameController API.
    /// Bundle SDL2.dll with your app (recommended: x64 SDL2.dll).
    /// </summary>
    internal static class Sdl2Native
    {
        // SDL init flags
        internal const uint SDL_INIT_TIMER = 0x00000001;
        internal const uint SDL_INIT_AUDIO = 0x00000010;
        internal const uint SDL_INIT_VIDEO = 0x00000020;
        internal const uint SDL_INIT_JOYSTICK = 0x00000200;
        internal const uint SDL_INIT_HAPTIC = 0x00001000;
        internal const uint SDL_INIT_GAMECONTROLLER = 0x00002000;
        internal const uint SDL_INIT_EVENTS = 0x00004000;

        internal enum SDL_GameControllerButton
        {
            SDL_CONTROLLER_BUTTON_INVALID = -1,
            SDL_CONTROLLER_BUTTON_A = 0,
            SDL_CONTROLLER_BUTTON_B = 1,
            SDL_CONTROLLER_BUTTON_X = 2,
            SDL_CONTROLLER_BUTTON_Y = 3,
            SDL_CONTROLLER_BUTTON_BACK = 4,
            SDL_CONTROLLER_BUTTON_GUIDE = 5,
            SDL_CONTROLLER_BUTTON_START = 6,
            SDL_CONTROLLER_BUTTON_LEFTSTICK = 7,
            SDL_CONTROLLER_BUTTON_RIGHTSTICK = 8,
            SDL_CONTROLLER_BUTTON_LEFTSHOULDER = 9,
            SDL_CONTROLLER_BUTTON_RIGHTSHOULDER = 10,
            SDL_CONTROLLER_BUTTON_DPAD_UP = 11,
            SDL_CONTROLLER_BUTTON_DPAD_DOWN = 12,
            SDL_CONTROLLER_BUTTON_DPAD_LEFT = 13,
            SDL_CONTROLLER_BUTTON_DPAD_RIGHT = 14,
            SDL_CONTROLLER_BUTTON_MISC1 = 15,
            SDL_CONTROLLER_BUTTON_PADDLE1 = 16,
            SDL_CONTROLLER_BUTTON_PADDLE2 = 17,
            SDL_CONTROLLER_BUTTON_PADDLE3 = 18,
            SDL_CONTROLLER_BUTTON_PADDLE4 = 19,
            SDL_CONTROLLER_BUTTON_TOUCHPAD = 20,
            SDL_CONTROLLER_BUTTON_MAX = 21
        }

        internal enum SDL_GameControllerAxis
        {
            SDL_CONTROLLER_AXIS_INVALID = -1,
            SDL_CONTROLLER_AXIS_LEFTX = 0,
            SDL_CONTROLLER_AXIS_LEFTY = 1,
            SDL_CONTROLLER_AXIS_RIGHTX = 2,
            SDL_CONTROLLER_AXIS_RIGHTY = 3,
            SDL_CONTROLLER_AXIS_TRIGGERLEFT = 4,
            SDL_CONTROLLER_AXIS_TRIGGERRIGHT = 5,
            SDL_CONTROLLER_AXIS_MAX = 6
        }
		
		[DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
		internal static extern IntPtr SDL_RWFromFile(string file, string mode);

		[DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern int SDL_GameControllerAddMappingsFromRW(IntPtr rw, int freerw);

		[DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
		public static extern int SDL_SetHint(string name, string value);

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern int SDL_Init(uint flags);

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern void SDL_Quit();

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern void SDL_PumpEvents();

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern int SDL_NumJoysticks();
		
		[DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern IntPtr SDL_JoystickNameForIndex(int device_index);

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern bool SDL_IsGameController(int joystick_index);

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern IntPtr SDL_GameControllerOpen(int joystick_index);

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern void SDL_GameControllerClose(IntPtr gamecontroller);

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern IntPtr SDL_GameControllerName(IntPtr gamecontroller);

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern byte SDL_GameControllerGetButton(IntPtr gamecontroller, SDL_GameControllerButton button);

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern short SDL_GameControllerGetAxis(IntPtr gamecontroller, SDL_GameControllerAxis axis);

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern int SDL_GameControllerAddMappingsFromFile(
            [MarshalAs(UnmanagedType.LPStr)] string file);

        [DllImport("SDL2.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern IntPtr SDL_GetError();

        internal static string GetErrorString()
        {
            var ptr = SDL_GetError();
            return ptr == IntPtr.Zero ? string.Empty : Marshal.PtrToStringAnsi(ptr) ?? string.Empty;
        }
    }
}
