using System;

namespace PolProcessCycler.Input
{
    internal enum InputKind
    {
        Button,
        AxisPositive,
        AxisNegative
    }

    /// <summary>
    /// A single bindable input (button or axis threshold).
    /// </summary>
    internal sealed class InputBinding
    {
        public InputKind Kind { get; set; } = InputKind.Button;
        public Sdl2Native.SDL_GameControllerButton Button { get; set; } = Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_DPAD_RIGHT;
        public Sdl2Native.SDL_GameControllerAxis Axis { get; set; } = Sdl2Native.SDL_GameControllerAxis.SDL_CONTROLLER_AXIS_LEFTX;

        /// <summary>
        /// Threshold in normalized [-1..1] space.
        /// For AxisPositive: fires when value >= Threshold.
        /// For AxisNegative: fires when value <= -Threshold.
        /// </summary>
        public float Threshold { get; set; } = 0.75f;

        public string Display
        {
            get
            {
                return Kind switch
                {
                    InputKind.Button => ButtonToNiceName(Button),
                    InputKind.AxisPositive => $"{AxisToNiceName(Axis)} + (>{Threshold:0.00})",
                    InputKind.AxisNegative => $"{AxisToNiceName(Axis)} - (>{Threshold:0.00})",
                    _ => "(unknown)"
                };
            }
        }

        private static string ButtonToNiceName(Sdl2Native.SDL_GameControllerButton b) => b switch
        {
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_A => "A / Cross",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_B => "B / Circle",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_X => "X / Square",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_Y => "Y / Triangle",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_LEFTSHOULDER => "LB / L1",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_RIGHTSHOULDER => "RB / R1",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_BACK => "Back / Share",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_START => "Start / Options",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_GUIDE => "Guide / PS",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_DPAD_LEFT => "D-pad Left",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_DPAD_RIGHT => "D-pad Right",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_DPAD_UP => "D-pad Up",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_DPAD_DOWN => "D-pad Down",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_LEFTSTICK => "L3",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_RIGHTSTICK => "R3",
            Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_TOUCHPAD => "Touchpad",
            _ => b.ToString()
        };

        private static string AxisToNiceName(Sdl2Native.SDL_GameControllerAxis a) => a switch
        {
            Sdl2Native.SDL_GameControllerAxis.SDL_CONTROLLER_AXIS_LEFTX => "Left Stick X",
            Sdl2Native.SDL_GameControllerAxis.SDL_CONTROLLER_AXIS_LEFTY => "Left Stick Y",
            Sdl2Native.SDL_GameControllerAxis.SDL_CONTROLLER_AXIS_RIGHTX => "Right Stick X",
            Sdl2Native.SDL_GameControllerAxis.SDL_CONTROLLER_AXIS_RIGHTY => "Right Stick Y",
            Sdl2Native.SDL_GameControllerAxis.SDL_CONTROLLER_AXIS_TRIGGERLEFT => "LT / L2",
            Sdl2Native.SDL_GameControllerAxis.SDL_CONTROLLER_AXIS_TRIGGERRIGHT => "RT / R2",
            _ => a.ToString()
        };
    }

    internal sealed class ControllerBindings
    {
        public InputBinding Forward { get; set; } = new()
        {
            Kind = InputKind.Button,
            Button = Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_DPAD_RIGHT
        };

        public InputBinding Back { get; set; } = new()
        {
            Kind = InputKind.Button,
            Button = Sdl2Native.SDL_GameControllerButton.SDL_CONTROLLER_BUTTON_DPAD_LEFT
        };
    }
}
